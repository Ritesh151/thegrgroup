import React from "react";
import { useParams } from "react-router-dom";

const SingleProduct = () => {
  const { id } = useParams();

  return (
    <div className="container my-5 text-center">
      <h2>Product Details</h2>
      <p>Showing details for product ID: {id}</p>
      {/* Add actual product logic here later */}
    </div>
  );
};

export default SingleProduct;
