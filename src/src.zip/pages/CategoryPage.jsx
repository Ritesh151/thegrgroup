// src/pages/CategoryPage.jsx
import React from 'react';
import { useParams } from 'react-router-dom';

const CategoryPage = () => {
  const { name } = useParams();

  return (
    <div className="container text-center py-5">
      <h2 style={{ color: 'goldenrod' }}>Category: {name}</h2>
      <p>Dynamic category page coming soon...</p>
    </div>
  );
};

export default CategoryPage;
